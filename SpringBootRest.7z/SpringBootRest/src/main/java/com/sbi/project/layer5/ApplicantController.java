package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@RestController
@RequestMapping("/applicants")
public class ApplicantController {

	@Autowired
	ApplicantService applicantService;

	public ApplicantController() {
		System.out.println("ApplicantController() constructor...");
	}

	@RequestMapping("/getApplicants") // localhost:8080/emps/getEmps
	public List<Applicant> getAllApplicants() {
		System.out.println("/getApplicants");
		return applicantService.getAllApplicants();
	}

	@RequestMapping("/getApplicant/{applicantId}")
	public String getApplicant(@PathVariable int applicantId) {
		for (Applicant applicant : applicantService.getAllApplicants()) {
			if (applicant.getApplicantId() == applicantId) {

				return applicant.toString();
			} else

				continue;
		}

		return "Applicant id " + applicantId + " not found";

	}

	@RequestMapping("/deleteApplicant/{appId}")
	public String deleteApplicant(@PathVariable Integer appId) {

		for (Applicant applicant : applicantService.getAllApplicants()) {
			if (applicant.getApplicantId() == appId) {
				applicantService.deleteAplicantservice(appId);
				return "Applicant " + appId + " deleted";
			} else
				continue;
		}

		return "Applicant Id " + appId + "not found";

	}

	@PutMapping("/updateApplicant")
	public String updateApplicant(@RequestBody Applicant applicantObj) {

		for (Applicant applicant : applicantService.getAllApplicants()) {
			if (applicant.getApplicantId() == applicantObj.getApplicantId()) {
				applicantService.deleteAplicantservice(applicant.getApplicantId());
				applicantService.createApplicationService(applicantObj);
				System.out.println("Applicant " + applicantObj.getApplicantId() + " modified");
				return "Applicant " + applicantObj.getApplicantId() + " modified";
			} else
				continue;
		}

		return "Applicant " + applicantObj.getApplicantId() + " not found";
	}

//	@PostMapping("/addApplicant")
//	public String addApplicant(@RequestBody Applicant applicant) {
//		
//		List<Address> addressList = new ArrayList<Address>();
//		Address address = new Address();
//		address.setAddresstype("Home");
//		address.setArea("Area");
//		address.setCity("City 1");
//		address.setCountry("Country 1");
//		address.setPin(641038);
//		address.setState("State 1");
//		address.setStreet("Street 1");
//		addressList.add(address);
//		
//		
//		Applicant appli = new Applicant();
//		//applicant.setApplicantId(12345);
//		appli.setAdhaarNumber("1212321312");
//		appli.setAnnualIncome(12312);
//		appli.setApplicantBirthdate("2008-03-12");
//		appli.setApplicantFatherName("Applicant 1 father");
//		//appli.setApplicantMotherName("Applicant 1 Mother");
//		appli.setApplicantName("Applicant 1");
//		appli.setAccountType("Savings");
//		appli.setMarried("Single");
//		appli.setOccupation("Occupation");
//		appli.setPanCard("ASDFG1234A");
//		appli.setPhoto("photo1");
//		appli.setApplicationStatus("APPLIED");
//		appli.setHomeAddress(addressList);
//		address.setApplicant(applicant);*/
//		
//		
//		applicantService.createApplicant(applicant);
//		return "Applicant created";
//		//return "Entret";
//	}
//	@RequestMapping("/getApplicants") // localhost:8080/emps/getEmps
//	public List<Applicant> getAllApplicants() {
//		System.out.println("/getApplicants");
//		return applicantService.
//	}
	/*
	 * @RequestMapping("/getEmp/{eno}") // localhost:8080/emps/getEmp/7839 public
	 * Employee getEmployee(@PathVariable("eno") int employeeNumberToSearch) {
	 * System.out.println("/getEmp"); boolean employeeFound=false; Employee
	 * employeeObject = null; for(int i=0;i<staff.size();i++) { employeeObject =
	 * staff.get(i); if(employeeObject.getEmployeeNumber() ==
	 * employeeNumberToSearch) { employeeFound = true; break; } }
	 * if(employeeFound==true) return employeeObject; else throw new
	 * RuntimeException("Employee Not Found"); }
	 * 
	 * @RequestMapping("/deleteEmp/{eno}") // localhost:8080/emps/deleteEmp/7839
	 * public String deleteEmployee(@PathVariable("eno") int employeeNumberToDelete)
	 * { System.out.println("/deleteEmp"); boolean employeeFound=false; Employee
	 * employeeObject = null; for(int i=0;i<staff.size();i++) { employeeObject =
	 * staff.get(i); if(employeeObject.getEmployeeNumber() ==
	 * employeeNumberToDelete) { employeeFound = true; staff.remove(i); break; } }
	 * if(employeeFound==true) return
	 * "Employee Object deleted : "+employeeNumberToDelete; else return
	 * "Employee Object NOT found : "+employeeNumberToDelete; }
	 * 
	 * @RequestMapping("/updateEmp") // localhost:8080/emps/updateEmp/7839 public
	 * String updateEmployee(@RequestBody Employee employeeObjectToModify) {
	 * System.out.println("/updateEmp"); boolean employeeFound=false; Employee
	 * employeeObject = null; for(int i=0;i<staff.size();i++) { employeeObject =
	 * staff.get(i); if(employeeObject.getEmployeeNumber() ==
	 * employeeObjectToModify.getEmployeeNumber()) { employeeFound = true;
	 * staff.remove(i); staff.add(employeeObjectToModify); break; } }
	 * if(employeeFound==true) return "Employee Object successfully modified"; else
	 * return
	 * "Employee Object NOT found : "+employeeObjectToModify.getEmployeeNumber();
	 * 
	 * }
	 * 
	 * @RequestMapping("/addEmp") // localhost:8080/emps/updateEmp/7839 public
	 * String addEmployee(@RequestBody Employee employeeObjectToAdd) {
	 * System.out.println("/addEmp"); boolean employeeFound=false; Employee
	 * employeeObject = null; for(int i=0;i<staff.size();i++) { employeeObject =
	 * staff.get(i); if(employeeObject.getEmployeeNumber() ==
	 * employeeObjectToAdd.getEmployeeNumber()) { employeeFound = true; break; } }
	 * if(employeeFound==true) return
	 * "Employee with this employeeNumber already exists!!!"; else {
	 * staff.add(employeeObjectToAdd); return
	 * "Employee Object addedd succesfully : "; }
	 * 
	 * }
	 */
}
