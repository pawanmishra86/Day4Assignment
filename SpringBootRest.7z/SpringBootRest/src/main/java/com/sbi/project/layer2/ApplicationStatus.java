package com.sbi.project.layer2;

public interface ApplicationStatus {
	 String APPLIED="Applied";
	 String IN_PROGRESS="In Progress";
	 String APPROVED="Approved";
	 String REJECTED="Rejected";
}
